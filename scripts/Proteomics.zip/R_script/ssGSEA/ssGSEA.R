library(GSVA)
library(GSEABase)
library(GSVAdata)
setwd("D:/科研课题/9.0 AFPGC_蛋白质组学/ssGSEA-HALLMARK")
geneSets <- getGmt("HALLMARK.gmt")
mydata <- read.table("Input_Protein.txt",header=T)
mydata= na.omit(mydata)
test1<-aggregate(x=mydata,by=list(mydata$Symbol),FUN=mean,na.rm=T) 
head(test1)
test1 = test1[,-2]
name=test1[,1]
exp=test1[,-1]
row.names(exp)=name
mydata= as.matrix(exp)
mydata=log2(mydata+1)
mydata = t(mydata)
z = scale(mydata, center = TRUE, scale = TRUE)
z=t(z)
mydata=z
mydata = as.matrix(mydata)
res_es <- gsva(mydata, geneSets,method="gsva", ssgsea.norm=F,min.sz=1, max.sz=500, verbose=FALSE, parallel.sz=1)
write.csv(res_es,file = "ssGSEA_AFPGC_HALLMARK.csv")
