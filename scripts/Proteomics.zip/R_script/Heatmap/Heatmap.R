library(circlize)
library(ComplexHeatmap)
setwd("D:/科研课题/9.0 AFPGC_蛋白质组学/Figure 2蛋白组/3.0 基因表达谱")
Data= read.table("Genematrix-metastasis.txt",header = T, row.names = 1)
Data = as.matrix(Data)
z=t(Data)
z2 = scale(z, center = T, scale = T)
Matrix = t(z2)
Matrix = as.matrix(Matrix)
range(Matrix)

#????????
colgroup=read.table("annoation.txt",sep="\t",header=TRUE,row.names=1)
Group2= subset(colgroup, select = Group)
Group2= t(Group2)
Group2= as.numeric(Group2)

Age= subset(colgroup, select = Age)
Age= t(Age)
Age= as.numeric(Age)

Gender= subset(colgroup, select = Gender)
Gender= t(Gender)
Gender= as.numeric(Gender)

Differentiation = subset(colgroup, select = Differentiation)
Differentiation= t(Differentiation)
Differentiation= as.numeric(Differentiation)

AFP = subset(colgroup, select = AFP)
AFP= t(AFP)
AFP= as.numeric(AFP)

col2 = list(Group2= c("0"="#e5dddf","1"="#f8bea4"),
            Age= c("0"="#d3c4c8","1"="#638394"),
            Gender= c("0"="#ea8c94","1"="#a89283"),
            Differentiation= c("0"="#c2b0c0","1"="#c6885c","2"="grey"),
            AFP= c("0"="#C6D8EF","1"="#FED976")
            )
df2 = data.frame(Group2,Age,Gender,Differentiation,AFP)
annotation =  HeatmapAnnotation(df = df2, col = col2)


Heatmap(Matrix,name = " ",
        col = colorRamp2(c(-2,0,2), c("#8aa9be","white","#ea8c94")),
        top_annotation = annotation,
        show_heatmap_legend = T,
        border = F,
        show_column_names = F,
        show_row_names = T,
        column_title = NULL,
        cluster_columns =F,
        cluster_rows = T)
