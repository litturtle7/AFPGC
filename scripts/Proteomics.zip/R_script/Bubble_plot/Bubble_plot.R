library(ggplot2)
setwd("D:/科研课题/9.0 AFPGC_蛋白质组学/Figure 2蛋白组/TvsN/气泡图")
pathway = read.csv("Input_low.csv",header=TRUE,row.names=1,check.names = FALSE)  
p = ggplot(pathway,aes(Percent,Pathways))
p=p + geom_point()  
# ?޸????Ĵ?С
p=p + geom_point(aes(size=Count))
# չʾ??ά????
pbubble = p+ geom_point(aes(size=Count,color=-1*log10(PValue)))
# ???ý???ɫ
pr = pbubble+scale_color_gradient(low="blue",high = "red")
# ????p????ͼ
pr = pr+labs(color=expression(-log[10](PValue)),size="Count",  
             x="Percent",y="Pathway name",title="Pathway enrichment")
pr + theme_bw()


