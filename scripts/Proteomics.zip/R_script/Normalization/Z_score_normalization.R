setwd("D:/科研课题/9.0 AFPGC_蛋白质组学/Ge2018_免疫评分/Zscore")
library(limma)
exp.rma<- read.table("Proteomics.txt",sep = "\t",header = T)
exp.rma <- as.matrix(exp.rma) #转换为矩阵
rownames(exp.rma)=exp.rma[,1] #将第一列设置为行名
exp.rma=exp.rma[,2:ncol(exp.rma)] #剔除第一列行名
exp.rma=avereps(exp.rma) #表达矩阵内重复基因的值替换为其平均值
exp.rma <- as.data.frame(exp.rma)
for (i in 1:ncol(exp.rma)) {
  exp.rma[,i] <- as.numeric(exp.rma[,i])
}
tACRG = t(exp.rma)
ACRG_Input =  scale(tACRG, center = T, scale =T)
tACRG_Input = t(ACRG_Input)
write.table(tACRG_Input,"Zscore.txt")
