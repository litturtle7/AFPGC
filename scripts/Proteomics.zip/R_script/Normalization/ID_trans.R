library(clusterProfiler)
library(org.Hs.eg.db) 
setwd("D:/科研课题/9.0 AFPGC_蛋白质组学/ID转换")
getwd()
dataset = read.table("Expression_matrix.txt", header = TRUE)
class(dataset)

data = dataset
test1<-aggregate(x=data,by=list(data$ENSEMBL),FUN=mean,na.rm=T)
Exp2=test1[,-2]
name = Exp2[,1]
row.names(Exp2)=name
Exp2=Exp2[,-1]

ids <- bitr(dataset$ENSEMBL,
            fromType = "ENSEMBL",
            toType = "SYMBOL",  
            OrgDb = org.Hs.eg.db) 
data=merge(dataset,ids,by="ENSEMBL")
head(data)
data[,1]=data[,54]
data= data[,-54]
#ȥ??
write.table(data,"AFPGC.txt")

dataset = t(dataset)
z = scale(dataset, center = TRUE, scale = TRUE)
z=t(z)
write.table(z,"NC_Z-score.txt")


