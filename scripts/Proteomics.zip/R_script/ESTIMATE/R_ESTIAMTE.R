setwd("D:/科研课题/9.0 AFPGC_蛋白质组学/ESTIMATE评分")

library(estimate)
estimateScore(input.ds = "sample_input_Ge2.gct",
              output.ds="Result_Ge2.gct", 
              platform="affymetrix")