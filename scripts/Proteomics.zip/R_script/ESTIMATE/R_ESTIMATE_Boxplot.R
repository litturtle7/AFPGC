library(ggplot2)
require(tidyverse)
require(ggplot2)
require(cowplot)
library(ggpubr)
library(reshape2)
setwd("D:/科研课题/9.0 AFPGC_蛋白质组学/ESTIMATE评分")

Expr <- read.table("Input_ESTIMATE_result_Ge2.txt",header = T)
A= melt(Expr,
        id.vars = c('NAME','Group'),
        variable.name='Score',
        value.name='abundance')
#??ͼ
p <-ggplot(data = A, aes(x=Score,y=abundance))+geom_boxplot(aes(fill=Group))
q <-p+ facet_wrap(~ Score, scales="free")
q+ stat_compare_means(aes(group = Group, label = "p.signif",method="wilcox.test"))


