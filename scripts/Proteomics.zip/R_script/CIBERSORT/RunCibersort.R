setwd("D:/科研课题/9.0 AFPGC_蛋白质组学/CIBERSORT")
source('Cibersort.R')

result1 <- CIBERSORT('LM22.txt','NC_Z-score.txt', perm = 1000, QN = T)
write.table(result1, "CIBERSORT_NC.txt")